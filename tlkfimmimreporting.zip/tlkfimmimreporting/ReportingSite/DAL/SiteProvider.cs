﻿using System;
using System.Collections.Generic;
using System.Web;

namespace ReportingSite.DAL
{
    public static class SiteProvider
    {
        static SiteProvider() { }

        public static Person Person
        {
            get
            {
                return Person.Instance; 
            }
        }

        public static Group Group
        {
            get
            {
                return Group.Instance;
            }
        }
    }
}