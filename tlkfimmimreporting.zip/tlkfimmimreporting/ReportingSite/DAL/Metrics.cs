﻿using System;
using System.Collections.Generic;
using System.Web;

namespace ReportingSite.DAL
{
    //class to hold metrics data to pass along to UI
    public class Metrics
    {
        public int NumberOfChanges { get; set; }
        public int NumberOfCreates { get; set; }
        public string UserWithMostRequests { get; set; }
        public int UserWithMostRequestsCount { get; set; }
        public string UserWithMostChanges { get; set; }
        public int UserWithMostChangesCount { get; set; }
    }
}