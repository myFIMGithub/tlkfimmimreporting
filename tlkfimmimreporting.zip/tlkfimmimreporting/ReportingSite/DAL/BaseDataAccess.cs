﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Configuration;

namespace ReportingSite.DAL
{
    public class BaseDataAccess
    {
        protected string connectionString = "";

        public BaseDataAccess()
        {
            connectionString = WebConfigurationManager.ConnectionStrings["ReportingDB"].ConnectionString;
        }
    }
}