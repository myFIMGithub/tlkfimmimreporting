﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data; 

namespace ReportingSite
{
    public partial class test : System.Web.UI.Page
    {
        DataTable dt = null;
        int rowNumber = 0; 
        protected void Page_Load(object sender, EventArgs e)
        {


            
            dt = ReportingSite.DAL.SiteProvider.Person.GetPersonObjectReportByTimeRange(50000);

            GridView1.DataSource = dt;
            GridView1.DataBind();

     
        }


        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            
            GridView1.DataBind();
        }

        protected void LinkButton_Click(object sender, EventArgs e)
        {
            //handle all the link buttons in the footer 
            LinkButton lb = (LinkButton)sender;
            rowNumber = int.Parse(lb.Text) - 1;
            GridView1.PageIndex = rowNumber; 
            GridView1.DataBind();

          

        }

        protected void GridView1_DataBound(object sender, EventArgs e)
        {
            GridViewRow pagerRow = GridView1.BottomPagerRow;

            LinkButton lbTemp;
            Label label1; 

            for (int i = 0; i < GridView1.PageCount; i++)
            {
                label1 = new Label();
                label1.Text = "| ";
                label1.ForeColor = System.Drawing.Color.FromName("#5F5F5F"); 
                pagerRow.Cells[0].Controls.Add(label1); 

                lbTemp = new LinkButton();
                lbTemp.ID = (i).ToString();
                lbTemp.Text = (i+1).ToString();
                lbTemp.CssClass = "gridPageLinkActive";
                lbTemp.Click += new EventHandler(LinkButton_Click);

                pagerRow.Cells[0].Controls.Add(lbTemp);

                label1 = new Label();
                label1.Text = " ";
                pagerRow.Cells[0].Controls.Add(label1);


            }

            ((LinkButton)pagerRow.Cells[0].FindControl(rowNumber.ToString())).Enabled = false;
            ((LinkButton)pagerRow.Cells[0].FindControl(rowNumber.ToString())).CssClass = "gridPageLinkCurrent";  
                

        }
    }
}