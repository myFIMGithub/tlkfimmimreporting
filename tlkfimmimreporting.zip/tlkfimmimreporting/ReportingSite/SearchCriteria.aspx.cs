﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ReportingSite
{
    public partial class SearchBy : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string type = Request.QueryString["type"].ToString();

            string what = "";
            string heading = "";

            switch (type)
            {
                case "person":
                    what = "What Person was changed";
                    heading = "Person Object Requests";
                    break;
                case "group":
                    what = "What Group was changed";
                    heading = "Group Object Requests";
                    break;
              

            }

            RadioButtonList2.Items[1].Text = what;
            lblHeading.Text = heading;

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string criteria = RadioButtonList2.SelectedValue;
            string range = RadioButtonList1.SelectedValue; 
            Response.Redirect("SearchResult.aspx?criteria=" + criteria + "&range=" + range + "&type=" + Request.QueryString["type"].ToString());
        }
    }
}