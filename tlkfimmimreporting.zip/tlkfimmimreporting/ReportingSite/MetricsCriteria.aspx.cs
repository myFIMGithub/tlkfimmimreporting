﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ReportingSite
{
    public partial class MatricsCriteria : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string type = Request.QueryString["type"].ToString();

            //string what = "";
            string heading = "";

            switch (type)
            {
                case "person":
                    // what = "What Person was changed";
                    heading = "Person Object Metrics";
                    break;
                case "group":
                    //what = "What Group was changed";
                    heading = "Group Object Metrics";
                    break;


            }

            //RadioButtonList2.Items[1].Text = what;
            lblHeading.Text = heading;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //string criteria = RadioButtonList2.SelectedValue;
            string range = RadioButtonList1.SelectedValue;
            Response.Redirect("MetricsResult.aspx?range=" + range + "&type=" + Request.QueryString["type"].ToString());
        }
    }
}