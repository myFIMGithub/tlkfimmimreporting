﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using ReportingSite.DAL;
using ReportingSite.UserControls;


namespace ReportingSite
{
    public partial class SearchResult : System.Web.UI.Page
    {
        DataTable dt = null;

        int rowNumber = 0; 
        protected void Page_Load(object sender, EventArgs e)
        {

            Label lblPageHeading = (Label) Master.FindControl("lblPageHeading");
            Button btnSearch = (Button)Master.FindControl("btnSearch");
            TextBox txtSearch = (TextBox)Master.FindControl("txtSearch");
            RequiredFieldValidator rfvSearch = (RequiredFieldValidator) Master.FindControl("rfvSearch");
            HeaderMenu headerMenu = (HeaderMenu)Master.FindControl("HeaderMenu");
            LinkButton lbLastMenu = (LinkButton)headerMenu.FindControl("lbLastMenu");

            btnSearch.Visible = true;
            txtSearch.Visible = true;
            rfvSearch.Visible = true; 
            

            string type = Request.QueryString["type"].ToString();
            string range = Request.QueryString["range"].ToString();
            string criteria = Request.QueryString["criteria"].ToString();

            int hours = 0;


            switch (range)
            {
                case "24hrs":
                    hours = 24;
                    break;
                case "72hrs":
                    hours = 72;
                    break;
                case "7days":
                    hours = 7 * 24;
                    break;
                case "14days":
                    hours = 14 * 24;
                    break;
                case "30days":
                    hours = 30 * 24;
                    break;
                default:
                    hours = 500000;
                    break;
            }

         
            string searchTerm1 = "";
            string searchTerm2 = "";
            string searchTerm3 = "";

            if (Page.IsPostBack)
            {
                string[] searchTerms = txtSearch.Text.Split(new char[] { ' ' });

                if (searchTerms.Length > 0) { if (searchTerms[0] != null) { searchTerm1 = searchTerms[0]; } }
                if (searchTerms.Length > 1) { if (searchTerms[1] != null) { searchTerm2 = searchTerms[1]; } }
                if (searchTerms.Length > 2) { if (searchTerms[2] != null) { searchTerm3 = searchTerms[2]; } }
            }

            

            switch (type)
            {
                case "person":
                    lblPageHeading.Text = "Person Object Search Result";
                    rfvSearch.Text = "Please enter person information to search";
                    lbLastMenu.PostBackUrl = "~/SearchCriteria.aspx?type=person";
                    
                    switch (criteria)
                    {
                        case "who":
                            dt = SiteProvider.Person.GetPersonObjectSearchByTimeRangeForRequestor(hours, searchTerm1, searchTerm2, searchTerm3);
                            break;
                        case "what":
                            dt = SiteProvider.Person.GetPersonObjectSearchByTimeRangeForTarget(hours, searchTerm1, searchTerm2, searchTerm3);
                            break; 
                        case "attribute":
                            dt = SiteProvider.Person.GetPersonObjectSearchByTimeRangeForAttribute(hours, searchTerm1, searchTerm2, searchTerm3);
                            break; 
                        default:
                            dt = SiteProvider.Person.GetPersonObjectSearchByTimeRangeForAll(hours, searchTerm1, searchTerm2, searchTerm3);
                            break;
                    }
                    break;
                case "group":
                    lblPageHeading.Text = "Group Object Search Result";
                    rfvSearch.Text = "Please enter group information to search";
                    lbLastMenu.PostBackUrl = "~/SearchCriteria.aspx?type=group";
                    switch (criteria)
                    {
                        case "who":
                            dt = SiteProvider.Group.GetGroupObjectSearchByTimeRangeForRequestor(hours, searchTerm1, searchTerm2, searchTerm3);
                            break;
                        case "what":
                            dt = SiteProvider.Group.GetGroupObjectSearchByTimeRangeForTarget(hours, searchTerm1, searchTerm2, searchTerm3);
                            break;
                        case "attribute":
                            dt = SiteProvider.Group.GetGroupObjectSearchByTimeRangeForAttribute(hours, searchTerm1, searchTerm2, searchTerm3);
                            break;
                        default:
                            dt = SiteProvider.Group.GetGroupObjectSearchByTimeRangeForAll(hours, searchTerm1, searchTerm2, searchTerm3);
                            break;
                    }
                    break;
                default:
                    lblPageHeading.Text = "Objects Search Result";
                    break;

            }

            if (dt != null)
            {
                gvObjectReport.DataSource = dt;

            }
            else
            {
                if (Page.IsPostBack)
                {
                    gvObjectReport.DataSource = new DataTable();
                    gvObjectReport.BorderWidth = 0;
                }
            }

            if (Page.IsPostBack) { 
            gvObjectReport.DataBind();
            lblNoSearchTextMessage.Visible = false; 
            }
            else
            {
                lblNoSearchTextMessage.Visible = true; 
            }


        }

        protected void gvObjectReport_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvObjectReport.PageIndex = e.NewPageIndex;
            gvObjectReport.DataBind();
        }

        protected void LinkButton_Click(object sender, EventArgs e)
        {
            //handle all the link buttons in the footer 
            LinkButton lb = (LinkButton)sender;
            rowNumber = int.Parse(lb.Text) - 1;
            gvObjectReport.PageIndex = rowNumber;
            gvObjectReport.DataBind();



        }

        protected void gvObjectReport_DataBound(object sender, EventArgs e)
        {
            GridViewRow pagerRow = gvObjectReport.BottomPagerRow;


            if (pagerRow != null)
            {


                LinkButton lbTemp;
                Label label1;
                pagerRow.HorizontalAlign = HorizontalAlign.Left;
                pagerRow.Cells[0].HorizontalAlign = HorizontalAlign.Left;
                pagerRow.Cells[0].CssClass = "divaligninpager";


                for (int i = 0; i < gvObjectReport.PageCount; i++)
                {
                    label1 = new Label();
                    label1.Text = "| ";
                    label1.ForeColor = System.Drawing.Color.FromName("#5F5F5F");
                    pagerRow.Cells[0].Controls.Add(label1);

                    lbTemp = new LinkButton();
                    lbTemp.ID = (i).ToString();
                    lbTemp.Text = (i + 1).ToString();
                    lbTemp.CssClass = "gridPageLinkActive";
                    lbTemp.Click += new EventHandler(LinkButton_Click);

                    pagerRow.Cells[0].Controls.Add(lbTemp);

                    label1 = new Label();
                    label1.Text = " ";
                    pagerRow.Cells[0].Controls.Add(label1);


                }

                if (gvObjectReport.PageCount > 0) { 
                ((LinkButton)pagerRow.Cells[0].FindControl(rowNumber.ToString())).Enabled = false;
                ((LinkButton)pagerRow.Cells[0].FindControl(rowNumber.ToString())).CssClass = "gridPageLinkCurrent";
                }
            }
        }


    }
}